-- Tabela: ENDERECO
INSERT INTO `ENDERECO` (`cod_endereco`,`logradouro`,`numero`,`bairro`,`cidade`,`estado`,`cep`,`latitude`,`longitude`) VALUES (1,'R. Bernardo Monteiro','62','Centro','Contagem','MG',32017170,'-19.914109','-44.085391');
INSERT INTO `ENDERECO` (`cod_endereco`,`logradouro`,`numero`,`bairro`,`cidade`,`estado`,`cep`,`latitude`,`longitude`) VALUES (2,'R. Joaquim Rocha','68-136','Betania','Contagem','MG',32017270,'-19.913053','-44.085282');
INSERT INTO `ENDERECO` (`cod_endereco`,`logradouro`,`numero`,`bairro`,`cidade`,`estado`,`cep`,`latitude`,`longitude`) VALUES (3,'R. Bueno Brandão','90-104','Centro','Contagem','MG',32041310,'-19.912810','-44.083424');

-- Tabela: IMAGEM
INSERT INTO `IMAGEM` (`cod_imagem`,`caminho`) VALUES (1,'EccoPark.PNG');
INSERT INTO `IMAGEM` (`cod_imagem`,`caminho`) VALUES (2,'RJoaquimRocha.PNG');
INSERT INTO `IMAGEM` (`cod_imagem`,`caminho`) VALUES (3,'RBuenoBrandao.PNG');

-- Tabela: ESTACIONAMENTO
INSERT INTO `ESTACIONAMENTO` (`cod_estacionamento`,`nome`,`cod_endereco`,`cod_imagem`,`coberto`,`telefone_1`,`telefone_2`) VALUES (1,'Ecco Park',1,1,1,'(31)3141-6108','(31)99849-1305');
INSERT INTO `ESTACIONAMENTO` (`cod_estacionamento`,`nome`,`cod_endereco`,`cod_imagem`,`coberto`,`telefone_1`,`telefone_2`) VALUES (2,'R Joaquim Rocha',2,2,0,NULL,NULL);
INSERT INTO `ESTACIONAMENTO` (`cod_estacionamento`,`nome`,`cod_endereco`,`cod_imagem`,`coberto`,`telefone_1`,`telefone_2`) VALUES (3,'R Bueno Brandão',3,3,0,'(31)98885-7443','(31)3049-3351');

-- Tabela: TIPO_SERVICO
INSERT INTO `TIPO_SERVICO` (`cod_tipo_servico`,`descricao`) VALUES (1,'Lava-Jato');

-- Tabela: SERVICO
INSERT INTO `SERVICO` (`cod_servico`,`cod_estacionamento`,`cod_tipo_servico`) VALUES (1,1,1);
INSERT INTO `SERVICO` (`cod_servico`,`cod_estacionamento`,`cod_tipo_servico`) VALUES (2,2,1);
INSERT INTO `SERVICO` (`cod_servico`,`cod_estacionamento`,`cod_tipo_servico`) VALUES (3,3,1);

-- Tabela: DIA
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (1,'Segunda');
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (2,'Terça');
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (3,'Quarta');
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (4,'Quinta');
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (5,'Sexta');
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (6,'Sábado');
INSERT INTO `DIA` (`cod_dia`,`descricao`) VALUES (7,'Domingo');

-- Tabela: HORARIO
INSERT INTO `PareFacil`.`HORARIO` (`cod_dia`, `hora_inico`, `hora_fim`, `cod_estacionamento`) VALUES ('1', '08:00', '17:00', '3');
INSERT INTO `PareFacil`.`HORARIO` (`cod_dia`, `hora_inico`, `hora_fim`, `cod_estacionamento`) VALUES ('2', '08:00', '17:00', '3');
INSERT INTO `PareFacil`.`HORARIO` (`cod_dia`, `hora_inico`, `hora_fim`, `cod_estacionamento`) VALUES ('3', '08:00', '17:00', '3');
INSERT INTO `PareFacil`.`HORARIO` (`cod_dia`, `hora_inico`, `hora_fim`, `cod_estacionamento`) VALUES ('4', '08:00', '17:00', '3');
INSERT INTO `PareFacil`.`HORARIO` (`cod_dia`, `hora_inico`, `hora_fim`, `cod_estacionamento`) VALUES ('5', '08:00', '17:00', '3');

-- Tabela: TEMPO
INSERT INTO `TEMPO` (`cod_tempo`,`tempo`) VALUES (1,'0 a 15m');
INSERT INTO `TEMPO` (`cod_tempo`,`tempo`) VALUES (2,'15 a 30m');
INSERT INTO `TEMPO` (`cod_tempo`,`tempo`) VALUES (3,'30 a 40m');
INSERT INTO `TEMPO` (`cod_tempo`,`tempo`) VALUES (4,'hora');
INSERT INTO `TEMPO` (`cod_tempo`,`tempo`) VALUES (5,'dia');
INSERT INTO `TEMPO` (`cod_tempo`,`tempo`) VALUES (6,'mês');

-- Tabele: VALOR
INSERT INTO `VALOR` (`cod_valor`,`cod_tempo`,`cod_estacionamento`,`preco`) VALUES (1,1,3,2.50);
INSERT INTO `VALOR` (`cod_valor`,`cod_tempo`,`cod_estacionamento`,`preco`) VALUES (2,2,3,5.00);
INSERT INTO `VALOR` (`cod_valor`,`cod_tempo`,`cod_estacionamento`,`preco`) VALUES (3,3,3,7.50);
INSERT INTO `VALOR` (`cod_valor`,`cod_tempo`,`cod_estacionamento`,`preco`) VALUES (4,4,3,10.00);
INSERT INTO `VALOR` (`cod_valor`,`cod_tempo`,`cod_estacionamento`,`preco`) VALUES (5,5,3,50.00);
INSERT INTO `VALOR` (`cod_valor`,`cod_tempo`,`cod_estacionamento`,`preco`) VALUES (6,6,3,160.00);


