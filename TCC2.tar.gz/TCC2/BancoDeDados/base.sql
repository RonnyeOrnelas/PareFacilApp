SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `PareFacil` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `PareFacil` ;

-- -----------------------------------------------------
-- Table `PareFacil`.`ENDERECO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`ENDERECO` (
  `cod_endereco` INT NOT NULL AUTO_INCREMENT,
  `logradouro` VARCHAR(100) NOT NULL,
  `numero` VARCHAR(11) NOT NULL,
  `bairro` VARCHAR(45) NOT NULL,
  `cidade` VARCHAR(80) NOT NULL,
  `estado` VARCHAR(2) NOT NULL,
  `cep` INT(8) NOT NULL,
  `latitude` VARCHAR(10) NOT NULL,
  `longitude` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`cod_endereco`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`IMAGEM`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`IMAGEM` (
  `cod_imagem` INT NOT NULL AUTO_INCREMENT,
  `caminho` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`cod_imagem`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`ESTACIONAMENTO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`ESTACIONAMENTO` (
  `cod_estacionamento` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `cod_endereco` INT NOT NULL,
  `cod_imagem` INT NOT NULL,
  `coberto` INT(1) NOT NULL DEFAULT 0,
  `telefone_1` VARCHAR(14) NULL,
  `telefone_2` VARCHAR(14) NULL,
  PRIMARY KEY (`cod_estacionamento`),
  INDEX `fk_endereco_idx` (`cod_endereco` ASC),
  INDEX `fk_imagem_idx` (`cod_imagem` ASC),
  CONSTRAINT `fk_endereco`
    FOREIGN KEY (`cod_endereco`)
    REFERENCES `PareFacil`.`ENDERECO` (`cod_endereco`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_imagem`
    FOREIGN KEY (`cod_imagem`)
    REFERENCES `PareFacil`.`IMAGEM` (`cod_imagem`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;


-- -----------------------------------------------------
-- Table `PareFacil`.`TIPO_SERVICO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`TIPO_SERVICO` (
  `cod_tipo_servico` INT NOT NULL AUTO_INCREMENT,
  `descricao` VARCHAR(80) NOT NULL,
  PRIMARY KEY (`cod_tipo_servico`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`SERVICO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`SERVICO` (
  `cod_servico` INT NOT NULL AUTO_INCREMENT,
  `cod_estacionamento` INT NOT NULL,
  `cod_tipo_servico` INT NOT NULL,
  PRIMARY KEY (`cod_servico`),
  INDEX `fk_estacionamento_idx` (`cod_estacionamento` ASC),
  INDEX `fk_tipo_servico_idx` (`cod_tipo_servico` ASC),
  CONSTRAINT `fk_estacionamento`
    FOREIGN KEY (`cod_estacionamento`)
    REFERENCES `PareFacil`.`ESTACIONAMENTO` (`cod_estacionamento`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tipo_servico`
    FOREIGN KEY (`cod_tipo_servico`)
    REFERENCES `PareFacil`.`TIPO_SERVICO` (`cod_tipo_servico`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`DIA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`DIA` (
  `cod_dia` INT NOT NULL AUTO_INCREMENT,
  `descricao` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cod_dia`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`HORARIO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`HORARIO` (
  `cod_horario` INT NOT NULL AUTO_INCREMENT,
  `cod_dia` INT NOT NULL,
  `hora_inico` TIME NOT NULL,
  `hora_fim` TIME NOT NULL,
  `cod_estacionamento` INT NOT NULL,
  PRIMARY KEY (`cod_horario`),
  INDEX `fk_dia_idx` (`cod_dia` ASC),
  INDEX `fk_estacionamento_horario_idx` (`cod_estacionamento` ASC),
  CONSTRAINT `fk_dia`
    FOREIGN KEY (`cod_dia`)
    REFERENCES `PareFacil`.`DIA` (`cod_dia`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_estacionamento_horario`
    FOREIGN KEY (`cod_estacionamento`)
    REFERENCES `PareFacil`.`ESTACIONAMENTO` (`cod_estacionamento`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`TEMPO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`TEMPO` (
  `cod_tempo` INT NOT NULL AUTO_INCREMENT,
  `tempo` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`cod_tempo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PareFacil`.`VALOR`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PareFacil`.`VALOR` (
  `cod_valor` INT NOT NULL AUTO_INCREMENT,
  `cod_tempo` INT NOT NULL,
  `cod_estacionamento` INT NOT NULL,
  `preco` DECIMAL NOT NULL,
  PRIMARY KEY (`cod_valor`),
  INDEX `fk_estacionamento_valor_idx` (`cod_estacionamento` ASC),
  INDEX `fk_valor_tempo_idx` (`cod_tempo` ASC),
  CONSTRAINT `fk_estacionamento_valor`
    FOREIGN KEY (`cod_estacionamento`)
    REFERENCES `PareFacil`.`ESTACIONAMENTO` (`cod_estacionamento`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_valor_tempo`
    FOREIGN KEY (`cod_tempo`)
    REFERENCES `PareFacil`.`TEMPO` (`cod_tempo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
